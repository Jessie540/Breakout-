﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CampbellJ_InstantWin : MonoBehaviour {




    void OnCollisionEnter2D(Collision2D coll)
    {
        
    }
    
}
