﻿



public static class CampbellJ_Data
{
    public static int score = 0;
    public static int lives = 5;
    public static int currentLevel = 0;

}

